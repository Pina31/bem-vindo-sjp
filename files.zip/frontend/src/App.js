import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Acolhimento a Migrantes e Refugiados</h1>
        <p>Bem-vindo ao aplicativo de acolhimento!</p>
      </header>
      <main>
        <section>
          <h2>Serviços Disponíveis</h2>
          <ul>
            <li>Educação</li>
            <li>Saúde</li>
            <li>Assistência Social</li>
            <li>Segurança Pública</li>
          </ul>
        </section>
      </main>
    </div>
  );
}

export default App;