# Aplicativo de Acolhimento a Migrantes e Refugiados

## Descrição
Este é um aplicativo projetado para acolher migrantes e refugiados na sua cidade, oferecendo serviços essenciais e informações úteis. Ele é intuitivo e fácil de usar, com suporte para múltiplos idiomas, e foi desenvolvido com escalabilidade em mente.

### Funcionalidades Principais
- **Educação:** Localização de escolas e cursos gratuitos.
- **Saúde:** Informações sobre hospitais, vacinação e agendamentos.
- **Assistência Social:** Centros de acolhimento e suporte psicológico.
- **Segurança Pública:** Telefones úteis e zonas seguras.

### Cores do Projeto
- **Azul, Verde e Branco.**

## Tecnologias Utilizadas
- **Frontend:** React
- **Backend:** Node.js com Express
- **Banco de Dados:** PostgreSQL
- **Internacionalização:** i18n
- **Hospedagem:** AWS ou Vercel

## Como Executar o Projeto
1. Clone este repositório: `git clone [URL_DO_REPO]`
2. Navegue até o diretório do projeto e instale as dependências:
   ```bash
   cd frontend
   npm install

   cd ../backend
   npm install
   ```
3. Inicie o servidor backend:
   ```bash
   cd backend
   npm start
   ```
4. Inicie o frontend:
   ```bash
   cd frontend
   npm start
   ```